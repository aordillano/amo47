<!--Alieyah Ordillano, 10/06/2023, IT 202-001, Section 001 Unit 3 Assignment, amo47@njit.edu-->
<html>
    <head>
        <title>CynoShoes</title>
    </head>
    <body>
        <!-- displays error message when not connected to database -->
        <main>
            <h1>Database Error</h1>
            <p>There was an error connecting to the database</p>
            <p>Error message: <?php echo $error_message;?></p>
        </main>
    </body>
</html>