<!--Alieyah Ordillano, 10/06/2023, IT 202-001, Section 001 Unit 3 Assignment, amo47@njit.edu-->
<header>
    <img id="north_star_1" src='images/north_star.png' alt='CynoShoes North Star Logo' height='60'/>
    <h1 style="background-color = white;">CynoShoes</h1>
    <img id="north_star_2" src='images/north_star.png' alt='CynoShoes North Star Logo' height='60'/>
    <h2 style="background-color = white;">123 Paradise St, Jersey City, NJ 07307</h2>
</header>