<!--Alieyah Ordillano, 10/06/2023, IT 202-001, Section 001 Unit 3 Assignment, amo47@njit.edu-->
<footer>
    <h5>
        <p>Alieyah Ordillano, 10/06/2023, IT 202-001, Section 001 Unit 3 Assignment, 
            <a href="emailto:amo47@njit.edu">amo47@njit.edu</a> 
        </p>
    </h5>
</footer>